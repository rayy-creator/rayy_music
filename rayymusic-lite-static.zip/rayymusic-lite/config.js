// rayymusic-lite berjalan sebagai website statis di GitHub Pages.
// Pencarian musik memakai iTunes Search API dan lirik memakai LRCLIB.
