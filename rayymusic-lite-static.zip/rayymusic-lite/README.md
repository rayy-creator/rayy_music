# rayymusic-lite

**your music, your world**

Versi ini adalah **website statis murni** untuk GitHub Pages. Tidak membutuhkan Node.js, `npm install`, `server.js`, atau panel Pterodactyl untuk frontend.

## Deploy ke GitHub Pages
1. Buat repository GitHub bernama `rayymusic-lite`.
2. Upload semua isi folder ini ke root repository, termasuk folder `.github`.
3. Buka **Settings → Pages** dan pilih **GitHub Actions** sebagai Build and deployment source.
4. Buka tab **Actions** dan tunggu workflow **Deploy static site to GitHub Pages** selesai.
5. Website akan tersedia di `https://USERNAME.github.io/rayymusic-lite/`.

## API
- Pencarian lagu dan preview: Apple/iTunes Search API (`https://itunes.apple.com/search`).
- Lirik: LRCLIB (`https://lrclib.net/api/get`).

Keduanya dipanggil langsung dari browser sehingga frontend dapat bekerja di hosting statis. API pihak ketiga dapat berubah, membatasi permintaan, atau tidak menyediakan preview/lirik untuk semua lagu.

## Catatan API backend lama
GitHub Pages **tidak dapat menjalankan API Node.js milik project** seperti `/api/search` atau `/api/lyrics`. Jika yang dimaksud adalah tetap memakai API backend lama, `server.js` harus di-deploy ke layanan backend terpisah dan frontend dikonfigurasi untuk mengakses URL backend tersebut. Versi statis ini memakai API publik langsung dan tidak menyertakan server backend.
